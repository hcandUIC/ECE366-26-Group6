// Code your testbench here
// or browse Examples
module four_bit_RCA_tb;

    reg [3:0] A, B;
    reg Cin;

    wire [3:0] S;
    wire Cout;

    four_bit_RCA_RCS uut (
        .A(A),
        .B(B),
        .Cin(Cin),
        .S(S),
        .Cout(Cout)
    );

    initial begin

      	//Stat waveform recording
        $dumpfile("dump.vcd");
        $dumpvars(0, four_bit_RCA_tb);

        // Test 1: 3 + 5 = 8
        A = 4'b0011;
        B = 4'b0101;
        Cin = 0;
        #10;

        // Test 2: 7 + 4 = 11
        A = 4'b0111;
        B = 4'b0100;
        Cin = 0;
        #10;

        // Test 3: 9 + 6 = 15
        A = 4'b1001;
        B = 4'b0110;
        Cin = 0;
        #10;

        // Test 4: 9 + 8 = 17
        A = 4'b1001;
        B = 4'b1000;
        Cin = 0;
        #10;

        // Test 5: 15 + 1 = 16
        A = 4'b1111;
        B = 4'b0001;
        Cin = 0;
        #10;

        // Test 6: 5 + 3 + 1 = 9
        A = 4'b0101;
        B = 4'b0011;
        Cin = 1;
        #10;

        #10;
        $finish;
    end

endmodule